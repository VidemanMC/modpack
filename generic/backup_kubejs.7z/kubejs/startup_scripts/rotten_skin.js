StartupEvents.registry('item', event => {
    event.create('rotten_skin')
    .displayName('Сгнившая кожа')
})