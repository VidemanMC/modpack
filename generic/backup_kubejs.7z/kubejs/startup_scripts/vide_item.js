StartupEvents.registry('item', event => {
    event.create('vide_item')
    .displayName('Vide item')
    .maxStackSize(1)
})