/// <reference path="./globals.d.ts" />
const Direction: typeof Facing
const Text: typeof Component
